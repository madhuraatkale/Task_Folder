package beans;

public class StudentRecord {
private int rollno;
private String name,email,grade;
private int phy,chem,maths,total;
public int getRollno() {
	return rollno;
}
public void setRollno(int rollno) {
	this.rollno = rollno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
public int getPhy() {
	return phy;
}
public void setPhy(int phy) {
	this.phy = phy;
}
public int getChem() {
	return chem;
}
public void setChem(int chem) {
	this.chem = chem;
}
public int getMaths() {
	return maths;
}
public void setMaths(int maths) {
	this.maths = maths;
}
public int getTotal() {
	return total;
}
public void setTotal(int total) {
	this.total = total;
}

}
